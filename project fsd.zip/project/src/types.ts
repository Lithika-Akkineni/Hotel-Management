export interface Hotel {
  id: string;
  name: string;
  location: string;
  price: number;
  rating: number;
  image: string;
  amenities: string[];
  description: string;
}

export interface SearchFilters {
  location: string;
  priceRange: [number, number];
  rating: number;
  amenities: string[];
}
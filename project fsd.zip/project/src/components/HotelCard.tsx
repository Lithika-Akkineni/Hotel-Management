import React from 'react';
import { Star, Wifi, School as Pool, Utensils, Dumbbell } from 'lucide-react';
import type { Hotel } from '../types';

interface HotelCardProps {
  hotel: Hotel;
}

export function HotelCard({ hotel }: HotelCardProps) {
  const amenityIcons: Record<string, React.ReactNode> = {
    'Free WiFi': <Wifi className="w-4 h-4" />,
    'Pool': <Pool className="w-4 h-4" />,
    'Restaurant': <Utensils className="w-4 h-4" />,
    'Gym': <Dumbbell className="w-4 h-4" />,
  };

  return (
    <div className="bg-white rounded-xl shadow-lg overflow-hidden transition-transform hover:scale-[1.02]">
      <img
        src={hotel.image}
        alt={hotel.name}
        className="w-full h-48 object-cover"
      />
      <div className="p-6">
        <div className="flex justify-between items-start">
          <h3 className="text-xl font-semibold">{hotel.name}</h3>
          <div className="flex items-center">
            <Star className="w-5 h-5 text-yellow-400 fill-current" />
            <span className="ml-1 font-medium">{hotel.rating}</span>
          </div>
        </div>
        <p className="text-gray-600 mt-2">{hotel.location}</p>
        <p className="text-gray-700 mt-3">{hotel.description}</p>
        <div className="flex gap-2 mt-4">
          {hotel.amenities.map((amenity) => (
            amenityIcons[amenity] && (
              <div key={amenity} className="tooltip" data-tip={amenity}>
                <div className="p-2 bg-gray-100 rounded-full">
                  {amenityIcons[amenity]}
                </div>
              </div>
            )
          ))}
        </div>
        <div className="mt-6 flex items-center justify-between">
          <div>
            <span className="text-2xl font-bold">${hotel.price}</span>
            <span className="text-gray-500">/night</span>
          </div>
          <button className="px-6 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors">
            Book Now
          </button>
        </div>
      </div>
    </div>
  );
}
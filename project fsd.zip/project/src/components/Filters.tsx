import React from 'react';
import { Sliders } from 'lucide-react';
import type { SearchFilters } from '../types';

interface FiltersProps {
  filters: SearchFilters;
  onFilterChange: (filters: SearchFilters) => void;
}

export function Filters({ filters, onFilterChange }: FiltersProps) {
  const amenityOptions = ['Free WiFi', 'Pool', 'Spa', 'Restaurant', 'Gym'];

  const handleAmenityToggle = (amenity: string) => {
    const newAmenities = filters.amenities.includes(amenity)
      ? filters.amenities.filter(a => a !== amenity)
      : [...filters.amenities, amenity];
    
    onFilterChange({ ...filters, amenities: newAmenities });
  };

  return (
    <div className="bg-white p-6 rounded-lg shadow-md">
      <div className="flex items-center gap-2 mb-4">
        <Sliders className="w-5 h-5" />
        <h3 className="text-lg font-semibold">Filters</h3>
      </div>

      <div className="space-y-6">
        <div>
          <label className="block text-sm font-medium mb-2">Price Range</label>
          <div className="flex items-center gap-4">
            <input
              type="number"
              value={filters.priceRange[0]}
              onChange={(e) => onFilterChange({
                ...filters,
                priceRange: [Number(e.target.value), filters.priceRange[1]]
              })}
              className="w-24 px-3 py-2 border rounded-md"
              placeholder="Min"
            />
            <span>-</span>
            <input
              type="number"
              value={filters.priceRange[1]}
              onChange={(e) => onFilterChange({
                ...filters,
                priceRange: [filters.priceRange[0], Number(e.target.value)]
              })}
              className="w-24 px-3 py-2 border rounded-md"
              placeholder="Max"
            />
          </div>
        </div>

        <div>
          <label className="block text-sm font-medium mb-2">Rating</label>
          <input
            type="range"
            min="0"
            max="5"
            step="0.5"
            value={filters.rating}
            onChange={(e) => onFilterChange({
              ...filters,
              rating: Number(e.target.value)
            })}
            className="w-full"
          />
          <div className="text-sm text-gray-600 mt-1">{filters.rating}+ stars</div>
        </div>

        <div>
          <label className="block text-sm font-medium mb-2">Amenities</label>
          <div className="space-y-2">
            {amenityOptions.map((amenity) => (
              <label key={amenity} className="flex items-center gap-2">
                <input
                  type="checkbox"
                  checked={filters.amenities.includes(amenity)}
                  onChange={() => handleAmenityToggle(amenity)}
                  className="rounded text-blue-600"
                />
                <span className="text-sm">{amenity}</span>
              </label>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}